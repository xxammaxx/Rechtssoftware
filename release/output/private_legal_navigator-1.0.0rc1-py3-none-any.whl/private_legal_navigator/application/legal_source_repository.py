"""Repository port for legal source provenance operations (M7-A).

Defines the interface that infrastructure must implement for:
- Source registry CRUD
- Snapshot storage and verification
- Instrument/Expression/Provision persistence
- Citation resolution
- FTS5 full-text search
"""

from abc import ABC, abstractmethod
from typing import Any
from uuid import UUID

from private_legal_navigator.domain.legal_source import (
    AuthorityTier,
    ImportStatus,
    InstrumentType,
    LegalCitation,
    LegalExpression,
    LegalInstrument,
    LegalProvision,
    LegalSource,
    ResolutionStatus,
    SourceSnapshot,
)
from private_legal_navigator.domain.sync import SyncItem, SyncRun


class LegalSourceRepository(ABC):
    """Port for legal source persistence operations."""

    # ── Sources ──────────────────────────────────

    @abstractmethod
    def initialize_schema(self) -> None: ...
    @abstractmethod
    def save_source(self, source: LegalSource) -> None: ...
    @abstractmethod
    def get_source_by_key(self, source_key: str) -> LegalSource | None: ...
    @abstractmethod
    def get_source(self, source_id: UUID) -> LegalSource | None: ...
    @abstractmethod
    def list_sources(self, *, enabled_only: bool = True) -> list[LegalSource]: ...

    # ── Snapshots ────────────────────────────────

    @abstractmethod
    def save_snapshot(self, snapshot: SourceSnapshot) -> None: ...
    @abstractmethod
    def get_snapshot(self, snapshot_id: UUID) -> SourceSnapshot | None: ...
    @abstractmethod
    def get_snapshot_by_hash(self, sha256: str) -> SourceSnapshot | None: ...
    @abstractmethod
    def update_snapshot_status(
        self, snapshot_id: UUID, status: ImportStatus, error: str = ""
    ) -> None: ...
    @abstractmethod
    def list_snapshots_for_source(self, source_key: str) -> list[SourceSnapshot]: ...
    @abstractmethod
    def count_instruments(self, source_key: str) -> int: ...
    @abstractmethod
    def count_provisions(self, source_key: str) -> int: ...

    # ── Instruments ──────────────────────────────

    @abstractmethod
    def save_instrument(self, instrument: LegalInstrument) -> None: ...
    @abstractmethod
    def get_instrument(self, instrument_id: UUID) -> LegalInstrument | None: ...
    @abstractmethod
    def get_instrument_by_abbreviation(self, abbrev: str) -> LegalInstrument | None: ...
    @abstractmethod
    def list_instruments(
        self,
        *,
        jurisdiction: str = "",
        instrument_type: InstrumentType | None = None,
        authority_tier: AuthorityTier | None = None,
    ) -> list[LegalInstrument]: ...

    # ── Expressions ──────────────────────────────

    @abstractmethod
    def save_expression(self, expression: LegalExpression) -> None: ...
    @abstractmethod
    def get_expression(self, expression_id: UUID) -> LegalExpression | None: ...
    @abstractmethod
    def list_expressions(
        self, instrument_id: UUID, *, current_only: bool = True
    ) -> list[LegalExpression]: ...
    @abstractmethod
    def get_current_expression(self, instrument_id: UUID) -> LegalExpression | None: ...

    # ── Provisions ───────────────────────────────

    @abstractmethod
    def save_provision(self, provision: LegalProvision) -> None: ...
    @abstractmethod
    def get_provision(self, provision_id: UUID) -> LegalProvision | None: ...
    @abstractmethod
    def get_provision_by_stable_key(
        self, expression_id: UUID, stable_key: str
    ) -> LegalProvision | None: ...
    @abstractmethod
    def get_provisions_for_expression(
        self, expression_id: UUID, *, parent_id: UUID | None = None
    ) -> list[LegalProvision]: ...

    # ── Citations ────────────────────────────────

    @abstractmethod
    def save_citation(self, citation: LegalCitation) -> None: ...
    @abstractmethod
    def get_citation(self, citation_id: UUID) -> LegalCitation | None: ...
    @abstractmethod
    def update_citation_resolution(
        self,
        citation_id: UUID,
        status: ResolutionStatus,
        instrument_id: UUID | None = None,
        provision_id: UUID | None = None,
        expression_id: UUID | None = None,
        confidence: str = "UNKNOWN",
        detail: str = "",
    ) -> None: ...

    # ── Search ───────────────────────────────────

    @abstractmethod
    def search_provisions_fts(self, query: str, limit: int = 50) -> list[dict[str, Any]]: ...
    @abstractmethod
    def rebuild_fts_index(self) -> None: ...

    # ── Sync (M7-B) ──────────────────────────────

    @abstractmethod
    def save_sync_run(self, sync_run: SyncRun) -> None:
        """Persist a new sync run."""
        ...

    @abstractmethod
    def update_sync_run(self, sync_run: SyncRun) -> None:
        """Update an existing sync run (e.g., completion counters and status)."""
        ...

    @abstractmethod
    def get_latest_sync_run(
        self, source_key: str, *, successful_only: bool = True
    ) -> SyncRun | None:
        """Retrieve the most recent sync run for a given source."""
        ...

    @abstractmethod
    def save_sync_item(self, item: SyncItem) -> None:
        """Persist a single sync item."""
        ...

    @abstractmethod
    def save_sync_items_batch(self, items: list[SyncItem], conn: Any) -> None:
        """Persist multiple sync items within an existing transaction."""
        ...

    @abstractmethod
    def list_runs(
        self, source_key: str | None = None, *, limit: int = 20, successful_only: bool = False
    ) -> list[SyncRun]:
        """List sync runs, ordered by most recent first (M7-B T303)."""
        ...

    @abstractmethod
    def get_items_for_run(self, sync_run_id: str) -> list[dict[str, object]]:
        """Return all sync items for a given run as raw dicts (M7-B T304)."""
        ...

    @abstractmethod
    def update_legal_source_catalog_stand_date(self, source_key: str, stand_date: str) -> None:
        """Update the last_catalog_stand_date on a legal source record."""
        ...
