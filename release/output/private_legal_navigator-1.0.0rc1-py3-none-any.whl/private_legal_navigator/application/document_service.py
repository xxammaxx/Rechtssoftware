"""Application service for Document use cases."""

import logging
import uuid

from private_legal_navigator.application.case_repository import CaseRepository
from private_legal_navigator.application.document_classifier import DocumentClassifier
from private_legal_navigator.application.document_repository import DocumentRepository
from private_legal_navigator.application.file_storage import FileStorage
from private_legal_navigator.application.text_extractor import TextExtractor
from private_legal_navigator.domain.document import Document
from private_legal_navigator.infrastructure.safe_logging import safe_log_event

logger = logging.getLogger(__name__)


class DocumentService:
    """Application service for document upload, listing, text extraction,
    classification, and retrieval."""

    def __init__(
        self,
        document_repo: DocumentRepository,
        file_storage: FileStorage,
        case_repo: CaseRepository,
        text_extractor: TextExtractor,
        classifier: DocumentClassifier,
    ) -> None:
        self._doc_repo = document_repo
        self._file_storage = file_storage
        self._case_repo = case_repo
        self._text_extractor = text_extractor
        self._classifier = classifier

    def upload_document(
        self,
        case_id: uuid.UUID,
        filename: str,
        content: bytes,
        mime_type: str,
        size_bytes: int,
    ) -> Document:
        """Upload a document with text extraction and optional classification."""

        # Case lookup
        if self._case_repo.get_by_id(case_id) is None:
            raise ValueError("Der Fall wurde nicht gefunden.")

        # Text extraction (returns ExtractionResult with text and optional error)
        result = self._text_extractor.extract(content)

        # Classification
        classification = self._classifier.classify(result.text)

        safe_log_event(
            logger,
            "document.classified",
            doc_type=str(classification.doc_type),
            confidence=classification.confidence,
            patterns=len(classification.matched_patterns),
        )

        doc = Document(
            filename=filename,
            mime_type=mime_type,
            size_bytes=size_bytes,
            case_id=case_id,
            text_content=result.text,
            extraction_error=result.error,
            doc_type=classification.doc_type,
            classification_confidence=classification.confidence,
            matched_patterns=classification.matched_patterns,
        )

        self._file_storage.store(doc.storage_path, content)
        self._doc_repo.save(doc)
        return doc

    def get_document(self, document_id: uuid.UUID) -> tuple[Document, bytes] | None:
        """Retrieve document metadata and content."""
        doc = self._doc_repo.get_by_id(document_id)
        if doc is None:
            return None
        content = self._file_storage.retrieve(doc.storage_path)
        return doc, content

    def get_document_text(self, document_id: uuid.UUID) -> Document | None:
        """Retrieve document with extracted text and classification."""
        return self._doc_repo.get_by_id(document_id)

    def list_case_documents(self, case_id: uuid.UUID) -> list[Document]:
        """List all documents for a given case."""
        return self._doc_repo.list_by_case(case_id)
